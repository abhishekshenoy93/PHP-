<?php

include_once("config.php");


$moviewatched = trim($_POST['movieshowname']);
$timeswatched = trim($_POST['timeswatched']);
$ratings = trim($_POST['rating']);
$datewatched = trim($_POST['datewatched']);

moviesandshows($moviewatched, $timeswatched, $ratings, $datewatched);

echo "Data Inserted";




?>
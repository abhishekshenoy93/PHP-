<?php



function insertData($fname, $lname, $emadd, $zip) {
global $mysqli;
$stmt = $mysqli->prepare("
insert into userinformation
(
firstname,
lastname,
emailaddress,
zipcode
)
values
(
?,
?,
?,
?
)
");
$stmt->bind_param("sssi", $fname, $lname, $emadd, $zip);
$stmt->execute();
$stmt->close();
}




function readUserInformation() {
    global $mysqli;
    $stmt = $mysqli->prepare("
    select distinct
           firstname, 
           lastname, 
           emailaddress, 
           zipcode 
    from userinformation;
    ");

    $stmt->execute();
    $stmt->bind_result(
        $resultfname,
        $resultlname,
        $resultemail,
        $resultzip
    );
    while ($stmt->fetch()){
        $row[] = array(
            'firstname' => $resultfname,
            'lastname'=> $resultlname,
            'emailaddress' => $resultemail,
            'zipcode' => $resultzip
        );
    }
    $stmt->close();
    return ($row);
}




function searchRecordByFirstName($fname) {
    global $mysqli;
    $stmt = $mysqli->prepare("
    select distinct
           firstname,
            lastname,
            emailaddress,
            zipcode
    from userinformation 
    where firstname = ?
    ");
    $stmt->bind_param("s", $fname);
    $stmt->execute();
    $stmt->bind_result($resultfname,
        $resultlname,
        $resultemail,
        $resultzip);
    while ($stmt->fetch()){
        $row[] = array(
            'firstname' => $resultfname,
            'lastname'=> $resultlname,
            'emailaddress' => $resultemail,
            'zipcode' => $resultzip
        );
    }
    $stmt->close();
    return ($row);
}

// ASSIGNMENT 4

// Insert Data
function moviesandshows($movname, $timewatched, $rating, $date) {
    global $mysqli;
    $stmt = $mysqli->prepare("
insert into movie
(
MovieShowName,
TimesWatched,
Rating,
DateWatched
)
values
(
?,
?,
?,
?
)
");
    $stmt->bind_param("sssi", $movname, $timewatched, $rating, $date);
    $stmt->execute();
    $stmt->close();
}

// View Movie Records
function readMovieInformation() {
    global $mysqli;
    $stmt = $mysqli->prepare("
    select distinct
           MovieShowName, 
           TimesWatched, 
           Rating, 
           DateWatched
    from movie
    ORDER BY rand()
    LIMIT 20;
    ");

    $stmt->execute();
    $stmt->bind_result(
        $resultshowname,
        $resulttimeswatched,
        $resultrating,
        $resultdatewatched
    );
    while ($stmt->fetch()){
        $row1[] = array(
            'movieshowname' => $resultshowname,
            'timeswatched'=> $resulttimeswatched,
            'rating' => $resultrating,
            'datewatched' => $resultdatewatched
        );
    }
    $stmt->close();
    return ($row1);
}

// Search Movie by Name
function searchRecordByMovieName($movname) {
    global $mysqli;
    $stmt = $mysqli->prepare("
    select distinct
            MovieShowName,
            TimesWatched,
            Rating,
            DateWatched
    from movie 
    where MovieShowName = ?
    ");
    $stmt->bind_param("s", $movname);
    $stmt->execute();
    $stmt->bind_result($resultshowname,
        $resulttimeswatched,
        $resultrating,
        $resultdatewatched);
    while ($stmt->fetch()){
        $row[] = array(
            'movieshowname' => $resultshowname,
            'timeswatched'=> $resulttimeswatched,
            'rating' => $resultrating,
            'datewatched' => $resultdatewatched
        );
    }
    $stmt->close();
    return ($row);
}

// Display Movie By Rating
function displayByRating() {
    global $mysqli;
    $stmt = $mysqli->prepare("
    select distinct
           MovieShowName, 
           TimesWatched, 
           Rating, 
           DateWatched
    from movie
    ORDER BY Rating;
    ");

    $stmt->execute();
    $stmt->bind_result(
        $resultshowname,
        $resulttimeswatched,
        $resultrating,
        $resultdatewatched
    );
    while ($stmt->fetch()){
        $row1[] = array(
            'movieshowname' => $resultshowname,
            'timeswatched'=> $resulttimeswatched,
            'rating' => $resultrating,
            'datewatched' => $resultdatewatched
        );
    }
    $stmt->close();
    return ($row1);
}

// Display Movie Watched More Than Once
function   moreThanOnceWatched() {
    global $mysqli;
    $stmt = $mysqli->prepare("
    select distinct
           MovieShowName, 
           TimesWatched, 
           Rating, 
           DateWatched
    from movie
    Where TimesWatched > 1;
    ");

    $stmt->execute();
    $stmt->bind_result(
        $resultshowname,
        $resulttimeswatched,
        $resultrating,
        $resultdatewatched
    );
    while ($stmt->fetch()){
        $row1[] = array(
            'movieshowname' => $resultshowname,
            'timeswatched'=> $resulttimeswatched,
            'rating' => $resultrating,
            'datewatched' => $resultdatewatched
        );
    }
    $stmt->close();
    return ($row1);
}
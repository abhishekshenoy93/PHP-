<?php


include_once("db-settings.php");
include_once("functions.php");

<?php
?>

<html>
<head>
    <title>Names</title>
</head>
<body>

    <table>
        <tr>
            <td>Create Record</td>
            <td><a href="userForm.php">CLICK HERE</a></td>
        </tr>
        <tr>
            <td>View Records</td>
            <td><a href="readUserInformation.php">CLICK HERE</a> </td>
        </tr>
        <tr>
            <td>Search Record</td>
            <td><a href="searchRecord.php">CLICK HERE</a> </td>
        </tr>

       <!-- ASSIGNMENT 4  -->

        <tr>
            <td>Movies Shows I watch</td>
            <td><a href="movieForm.php">CLICK HERE</a></td>
        </tr>
        <tr>
            <td>List 20 Records</td>
            <td><a href="readMovieInformation.php">CLICK HERE</a></td>
        </tr>
        <tr>
            <td>Search Movie Record</td>
            <td><a href="searchMovieRecord.php">CLICK HERE</a> </td>
        </tr>
        <tr>
            <td>Display By Rating</td>
            <td><a href="displayByRating.php">CLICK HERE</a> </td>
        </tr>
        <tr>
            <td>More Than Once Watched Movies</td>
            <td><a href="moreThanOnceWatched.php">CLICK HERE</a> </td>
        </tr>


    </table>

</body>
</html>


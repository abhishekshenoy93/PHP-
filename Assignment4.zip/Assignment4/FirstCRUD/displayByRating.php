<?php

include_once("config.php");


$displayMovieInformation = displayByRating();


foreach ($displayMovieInformation as $loopinformation) {
    echo $loopinformation['movieshowname'] . " ";

    echo $loopinformation['timeswatched'] . " ";

    echo $loopinformation['rating'] . " ";

    echo $loopinformation['datewatched'] . " ";
    echo "<br>";
}

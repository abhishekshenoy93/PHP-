<?php
?>

<html>
<head>
    <title>Movies</title>
</head>
<body>
<form name="dataInsert" action="movieData.php" method="post">
    <table>
        <tr>
            <td>MovieShowName</td>
            <td><input type="text" name="movieshowname" value=""></td>
        </tr>
        <tr>
            <td>TimesWatched</td>
            <td><input type="number" name="timeswatched" value=""></td>
        </tr>
        <tr>
            <td>Rating</td>
            <td><input type="number" name="rating" value=""></td>
        </tr>
        <tr>
            <td>DateWatched</td>
            <td><input type="datetime" name="datewatched" value=""></td>
        </tr>
        <tr>
            <td>Submit</td>
            <td><input type="submit" name="submit" value="insert/update"></td>
        </tr>
    </table>
</form>
</body>
</html>

